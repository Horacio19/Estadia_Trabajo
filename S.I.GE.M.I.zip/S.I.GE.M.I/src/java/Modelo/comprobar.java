package Modelo;

public class comprobar {
    public static void main(String[] args){
        try {
            // Obtener la instancia única de la clase conexion
            conexion c = conexion.getInstance();
            
            // Intentar conectar a la base de datos y verificar la conexión
            if (c.getConnection() != null) {
                System.out.println("Conexion exitosa");
            } else {
                System.out.println("Conexion erronea");
            }
        } catch (Exception e) {
            System.out.println("Error al conectar: " + e.getMessage());
        }
    }
}
