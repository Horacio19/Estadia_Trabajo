/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */

var modal = document.getElementById("myModal");
var btn = document.getElementById("ModalBtn");
var span = document.getElementsByClassName("close")[0];

// Abre el modal al hacer clic en el botón
btn.onclick = function () {
    modal.classList.add("show");
};

// Cierra el modal al hacer clic en el botón de cierre (X)
span.onclick = function () {
    modal.classList.remove("show");
};

// Cierra el modal si se hace clic fuera del contenido del modal
window.onclick = function (event) {
    if (event.target === modal) {
        modal.classList.remove("show");
    }
};



