package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;

public class conexion {
    private final String baseDatos = "siagemi";
    private final String servidor = "jdbc:postgresql://localhost:5432/" + baseDatos;
    private final String usuario = "CIDTFA";
    private final String password = "electronica09";
    
    public Connection conectar(){
        Connection cn = null;
        try{
            Class.forName("org.postgresql.Driver");
            cn = DriverManager.getConnection(servidor, usuario, password);
            System.out.println("Conexion Establecida!!!");
        }catch(Exception e){
            System.out.println("Error al conectar!!" + e.getMessage());
        }
        return cn;
    }
}
