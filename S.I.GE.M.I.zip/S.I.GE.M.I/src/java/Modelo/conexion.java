package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class conexion {
    private final String baseDatos = "siagemi";
    private final String servidor = "jdbc:postgresql://localhost:5432/" + baseDatos;
    private final String usuario = "cidtfa";
    private final String password = "electronica09";

    // Instancia estática única de la clase
    private static conexion instance;
    // Conexión a la base de datos
    private Connection cn;

    // Constructor privado para evitar instanciación desde fuera de la clase
    private conexion() throws SQLException {
        try {
            Class.forName("org.postgresql.Driver");
            cn = DriverManager.getConnection(servidor, usuario, password);
            System.out.println("Conexion Establecida!!!");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error al conectar!! " + e.getMessage());
            throw new SQLException(e);
        }
    }

    // Método estático público para obtener la instancia única de la clase
    public static conexion getInstance() throws SQLException {
        if (instance == null) {
            instance = new conexion();
        } else if (instance.getConnection().isClosed()) {
            instance = new conexion();
        }
        return instance;
    }

    // Método público para obtener la conexión
    public Connection getConnection() {
        return cn;
    }
    
    // Método público para cerrar la conexión
    public void closeConnection() {
        if (cn != null) {
            try {
                cn.close();
                System.out.println("Conexion Cerrada!!!");
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexion!! " + e.getMessage());
            }
        }
    }
}
